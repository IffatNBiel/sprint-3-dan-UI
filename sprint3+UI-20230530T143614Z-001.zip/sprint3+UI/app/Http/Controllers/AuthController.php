<?php

namespace App\Http\Controllers;

use App\Models\Jabatan;
use App\Models\Usaha;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use PHPUnit\Exception;

class AuthController extends Controller
{
    public function loginform()
    {
        return view("pages.auth.login");
    }

    public function login(Request $request)
    {
        $credential = $request->validate([
            "email" => "required|email|exists:users",
            "password" => "required"
        ]);
        if (Auth::attempt($credential)) {
            return redirect()->intended();
        } else {
            return back()->withErrors(["password" => "Password Wrong"]);
        }
    }

    public function registerform()
    {
        return view("pages.auth.register");
    }

    public function register(Request $request)
    {
        $data = $request->validate([
            "name" => "required",
            "email" => "required|unique:users",
            "password" => "required",
            "phone" => "required|numeric"
        ]);
        $dataUsaha = $request->validate([
            "nama_usaha" => "required",
            "bidang" => "required",
            "jumlah_pegawai" => "required"
        ]);
        DB::beginTransaction();
        try {
            $dataUsaha["nama"] = $dataUsaha["nama_usaha"];
            $usaha = new Usaha($dataUsaha);
            $usaha->save();

            $data["usaha_id"] = $usaha->id;
            $data["password"] = Hash::make($data["password"]);
            $data["jabatan_id"] = Jabatan::where("jabatan_name", "pemilik")->first()->id;
            $user = new User($data);
            $user->save();
            Auth::login($user);
            DB::commit();
        } catch (Exception $e) {
            DB::rollBack();
        }
        return redirect()->intended();
    }

    public function confirmForm()
    {
        return view("pages.auth.confirm");
    }

    public function confirm(Request $request)
    {
        $request->validate([
            "paket" => "required",
            "metode" => "required",
            "bukti" => "required"
        ]);
        $usaha = Usaha::find(Auth::user()->usaha_id);
        $usaha->activated_at = Carbon::now();
        $usaha->save();
        return redirect()->intended();
    }

    public function logout()
    {
        Auth::logout();
        return redirect()->intended();
    }

    public function pegawaiForm()
    {
        $jabatans = Jabatan::all();
        $pegawais = Auth::user()->usaha->users;
        return view("pages.auth.pegawai", compact("jabatans", "pegawais"));
    }
    public function tambahPegawai(Request $request){
        $data = $request->validate([
            "name" => "required",
            "email" => "required",
            "password" => "required",
            "phone" => "required|numeric",
            "gender" => "required",
            "jabatan_id" => "required",
        ]);
        $data["usaha_id"] = Auth::user()->usaha->id;
        $data["password"] = Hash::make($data["password"]);
        $pegawai = new User($data);
        $pegawai->save();
        return redirect("/pegawai");
    }

    public function detail($id)
    {
        $pegawai = User::find($id);
        return view("pages.auth.detail", compact("pegawai"));
    }

    public function editPegawaiForm($id)
    {
        $edit = true;
        $jabatans = Jabatan::all();
        $pegawai = User::find($id);
        $pegawais = Auth::user()->usaha->users;
        return view("pages.auth.pegawai", compact("jabatans", "pegawais", "pegawai", "edit"));
    }

    public function editPegawai($id, Request $request)
    {
        $data = $request->validate([
            "name" => "required",
            "email" => "required",
            "password" => "nullable",
            "phone" => "required|numeric",
            "gender" => "required",
            "jabatan_id" => "required",
        ]);
        $pegawai = User::find($id);
        $pegawai->name = $data["name"];
        $pegawai->email = $data["email"];
        $pegawai->phone = $data["phone"];
        $pegawai->gender = $data["gender"];
        $pegawai->jabatan_id = $data["jabatan_id"];
        if ($data["password"]) {
            $pegawai->password = Hash::make($data["password"]);
        }
        $pegawai->save();
        return redirect("/pegawai");
    }
}
