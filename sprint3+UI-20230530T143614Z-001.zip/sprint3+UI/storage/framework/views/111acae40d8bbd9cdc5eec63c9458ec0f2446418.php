<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Griees</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.5/flowbite.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="/css/style.css">
    <script src="https://code.jquery.com/jquery-3.6.4.slim.min.js"
            integrity="sha256-a2yjHM4jnF9f54xUQakjZGaqYs/V1CYvWpoqZzC2/Bw=" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
          rel="stylesheet">
</head>
<body class="flex w-screen">
<nav class="flex flex-col bg-primary w-1/4 gap-2 p-4 text-white h-screen">
    <a href="/" class="w-1/4">
        <img src="/images/logo.png" alt="">
    </a>
    <a href="/dashboard">Dashboard</a>
    <hr>
    <a href="/transaksi/tambah">Kasir</a>
    <hr>
    <a href="/produk">Produk</a>
    <hr>
    <a href="/stok">Stok Produk</a>
    <hr>
    <a href="/transaksi">Riwayat Transaksi</a>
    <hr>
    <button id="dropdownDefaultButton" data-dropdown-toggle="dropdown" class="text-start">Keuangan
    </button>
    <hr>
    <div id="dropdown" class="z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700">
        <ul class="py-2 text-sm text-gray-700" aria-labelledby="dropdownDefaultButton">
            <li>
                <a href="/keuangan/laporan" class="block px-4 py-2">Laporan Keuangan</a>
            </li>
            <li>
                <a href="/keuangan/masuk" class="block px-4 py-2">Arus Kas Masuk</a>
            </li>
            <li>
                <a href="/keuangan/keluar" class="block px-4 py-2">Arus Kas Keluar</a>
            </li>
        </ul>
    </div>
    <?php if(auth()->user() ? auth()->user()->jabatan->jabatan_name === "pemilik" : false): ?>
        <a href="/pegawai">Pegawai</a>
        <hr>
    <?php endif; ?>
</nav>

<main class="flex-grow bg-slate-100 px-4 h-screen overflow-y-hidden">
    <div class="flex justify-end items-center text-white font-bold px-4 bg-primary h-[10%] mb-4">
        <a href="/logout" class="flex items-center gap-2">Logout<span class="material-icons">person</span></a>
    </div>
    <?php echo $__env->yieldContent("content"); ?>
</main>
<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.5/flowbite.min.js"></script>
</body>
</html>
<?php /**PATH /home/dobberman/Code/PHP/ppl_alfan/sprint2/resources/views/layouts/auth.blade.php ENDPATH**/ ?>