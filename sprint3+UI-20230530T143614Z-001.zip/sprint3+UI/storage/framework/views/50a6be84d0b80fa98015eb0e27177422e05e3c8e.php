<?php $__env->startSection("content"); ?>
    <?php echo $__env->make("pages.stok.tambah", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("pages.stok.edit", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("pages.stok.detail", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(session("message")): ?>
        <div data-modal-target="popup-modal"></div>
        <div id="popup-modal" tabindex="-1"
             class="fixed flex z-50 p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
            <div class="relative w-full max-w-md max-h-full">
                <div class="relative rounded-lg shadow bg-white">
                    <button type="button"
                            class="absolute top-3 right-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-800 dark:hover:text-white"
                            data-modal-hide="popup-modal">
                        <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                             xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd"
                                  d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                  clip-rule="evenodd"></path>
                        </svg>
                        <span class="sr-only">Close modal</span>
                    </button>
                    <div class="p-6 text-center">
                        <svg aria-hidden="true" class="mx-auto mb-4 text-gray-400 w-14 h-14 dark:text-gray-200"
                             fill="none" stroke="currentColor" viewBox="0 0 24 24"
                             xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                        <h3 class="mb-5 text-lg font-normal text-gray-500 dark:text-gray-400"><?php echo e(session("message")); ?></h3>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="p-4 bg-white h-[calc(100vh-10%-1rem)] overflow-y-scroll">
        <div class="flex justify-between items-center">
            <h1 class="font-bold text-2xl">Stok Produk</h1>
            <button data-modal-target="tambahStok" data-modal-toggle="tambahStok"
                    class="px-4 py-2 bg-primary rounded-xl text-white my-2">Tambah Stok Produk
            </button>
        </div>
        <table class="w-full">
            <thead>
            <tr class="bg-primary text-white">
                <th class="border-2 border-gray-200 px-8 py-2">No.</th>
                <th class="border-2 border-gray-200 px-8 py-2">Id Produk</th>
                <th class="border-2 border-gray-200 px-8 py-2">Nama Produk</th>
                <th class="border-2 border-gray-200 px-8 py-2">Stok Produk</th>
                <th class="border-2 border-gray-200 px-8 py-2">Status</th>
                <th class="border-2 border-gray-200 px-8 py-2">Deskripsi</th>
                <th class="border-2 border-gray-200 px-8 py-2">Edit</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="<?php if($produk->stok===0): ?> bg-red-300 <?php endif; ?>">
                    <td data-modal-target="detailStok" data-modal-toggle="detailStok"
                        onclick="detailStok('<?php echo e($produk->nama); ?>','<?php echo e($produk->stok); ?>','<?php echo e($produk->deskripsi); ?>')"
                        class="border border-2 border-gray-200 p-2 text-center"><?php echo e($i+1); ?></td>
                    <td data-modal-target="detailStok" data-modal-toggle="detailStok"
                        onclick="detailStok('<?php echo e($produk->nama); ?>','<?php echo e($produk->stok); ?>','<?php echo e($produk->deskripsi); ?>')"
                        class="border border-2 border-gray-200 p-2"><?php echo e($produk->id); ?></td>
                    <td data-modal-target="detailStok" data-modal-toggle="detailStok"
                        onclick="detailStok('<?php echo e($produk->nama); ?>','<?php echo e($produk->stok); ?>','<?php echo e($produk->deskripsi); ?>')"
                        class="border border-2 border-gray-200 p-2"><?php echo e($produk->nama); ?></td>
                    <td data-modal-target="detailStok" data-modal-toggle="detailStok"
                        onclick="detailStok('<?php echo e($produk->nama); ?>','<?php echo e($produk->stok); ?>','<?php echo e($produk->deskripsi); ?>')"
                        class="border border-2 border-gray-200 p-2 text-center"><?php echo e($produk->stok); ?></td>
                    <td data-modal-target="detailStok" data-modal-toggle="detailStok"
                        onclick="detailStok('<?php echo e($produk->nama); ?>','<?php echo e($produk->stok); ?>','<?php echo e($produk->deskripsi); ?>')"
                        class="border border-2 border-gray-200 p-2 text-center"><?php echo e($produk->stok>0?"Tersedia":"Habis"); ?></td>
                    <td data-modal-target="detailStok" data-modal-toggle="detailStok"
                        onclick="detailStok('<?php echo e($produk->nama); ?>','<?php echo e($produk->stok); ?>','<?php echo e($produk->deskripsi); ?>')"
                        class="border border-2 border-gray-200 p-2"><?php echo e(Str::limit($produk->deskripsi, $limit = 20, $end = '...')); ?></td>
                    <td class="border border-2 border-gray-200 p-2 text-center">
                        <button onclick="editStok('<?php echo e($produk->id); ?>','<?php echo e($produk->nama); ?>','<?php echo e($produk->stok); ?>')"
                                data-modal-target="editStok" data-modal-toggle="editStok" class="material-icons">
                            edit
                        </button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.auth", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dobberman/Code/PHP/ppl_alfan/sprint2/resources/views/pages/stok/index.blade.php ENDPATH**/ ?>