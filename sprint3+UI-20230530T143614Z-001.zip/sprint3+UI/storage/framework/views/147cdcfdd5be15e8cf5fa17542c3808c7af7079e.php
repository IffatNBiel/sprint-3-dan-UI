<?php $__env->startSection("content"); ?>
    <main class="flex-grow bg-slate-100 p-4">
        <table>
            <tr>
                <th>No.</th>
                <th>Tanggal</th>
                <th>Aksi</th>
            </tr>
            <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i+1); ?></td>
                    <td><?php echo e($d->tanggal); ?></td>
                    <td><a href="laporan?tanggal=<?php echo e($d->tanggal); ?>">Detail</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.auth", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dobberman/Code/PHP/ppl_alfan/sprint2/resources/views/pages/keuangan/laporan.blade.php ENDPATH**/ ?>