<?php $__env->startSection("content"); ?>
    <div class="flex justify-between items-start h-[calc(100vh-10%-1rem)] bg-white p-4">
        <div class="h-full overflow-y-scroll">
            <table>
                <tr class="bg-primary text-white">
                    <th class="px-2 border-2 border-gray-200">Nama</th>
                    <th class="px-2 border-2 border-gray-200">Jabatan</th>
                    <th class="px-2 border-2 border-gray-200 w-1/12">Jenis Kelamin</th>
                    <th class="px-2 border-2 border-gray-200">Nomor Telp</th>
                    <th class="px-2 border-2 border-gray-200">Email</th>
                    <th class="px-2 border-2 border-gray-200">Password</th>
                    <th class="px-2 border-2 border-gray-200">Aksi</th>
                </tr>
                <?php $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center px-2 border-2 border-gray-200"><?php echo e($pegawai->name); ?></td>
                        <td class="text-center px-2 border-2 border-gray-200 capitalize"><?php echo e($pegawai->jabatan->jabatan_name); ?></td>
                        <td class="text-center px-2 border-2 border-gray-200"><?php echo e($pegawai->gender); ?></td>
                        <td class="text-center px-2 border-2 border-gray-200"><?php echo e($pegawai->phone); ?></td>
                        <td class="text-center px-2 border-2 border-gray-200"><?php echo e($pegawai->email); ?></td>
                        <td class="text-center px-2 border-2 border-gray-200">***</td>
                        <td class="text-center px-2 border-2 border-gray-200">
                            <a href="/pegawai/edit/<?php echo e($pegawai->id); ?>" class="material-icons">edit</a>
                            <a href="/pegawai/<?php echo e($pegawai->id); ?>" class="material-icons">visibility</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <form enctype="multipart/form-data" method="POST" class="flex flex-col gap-2">
            <?php echo csrf_field(); ?>
            <label for="name">Nama</label>
            <input type="text" name="name" id="name" class="form-input p-1" placeholder="Nama"
                   value="<?php echo e(isset($edit)?$pegawai->name:""); ?>">
            <label for="jabatan_id">Jabatan</label>
            <select name="jabatan_id" id="jabatan_id" class="form-input p-1">
                <option value selected disabled>Pilih Jabatan</option>
                <?php $__currentLoopData = $jabatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jabatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($jabatan->id); ?>" <?php if(isset($edit)): ?>
                        <?php echo e($pegawai->jabatan->id === $jabatan->id ? "selected" : ""); ?>

                        <?php endif; ?>><?php echo e($jabatan->jabatan_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="gender">Jenis Kelamin</label>
            <select name="gender" id="gender" class="form-input p-1">
                <option value selected disabled>Pilih Gender</option>
                <option value="L" <?php if(isset($edit)): ?>
                    <?php echo e($pegawai->gender === "L" ? "selected" : ""); ?>

                    <?php endif; ?>>Laki-laki
                </option>
                <option value="P" <?php if(isset($edit)): ?>
                    <?php echo e($pegawai->gender === "P" ? "selected" : ""); ?>

                    <?php endif; ?>>Perempuan
                </option>
            </select>
            <label for="phone">Nomor Telp</label>
            <input type="text" class="form-input p-1" name="phone" id="phone" placeholder="Nomor Telp"
                   value="<?php echo e(isset($edit)?$pegawai->phone:""); ?>">
            <label for="email">Email</label>
            <input type="email" class="form-input p-1" name="email" id="email" placeholder="Email"
                   value="<?php echo e(isset($edit)?$pegawai->email:""); ?>">
            <label for="password">Password</label>
            <input type="password" class="form-input p-1" name="password" id="password" placeholder="Password">
            <button class="bg-primary px-4 py-2 rounded-xl text-white font-medium"
                    type="submit"><?php echo e(isset($edit)?"Simpan":"Tambah"); ?></button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.auth", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dobberman/Code/PHP/ppl_alfan/sprint2/resources/views/pages/auth/pegawai.blade.php ENDPATH**/ ?>