<?php $__env->startSection("content"); ?>
    <main>
        <form action="/produk/edit/<?php echo e($produk->id); ?>" enctype="multipart/form-data" method="POST" class="flex flex-col">
            <?php echo csrf_field(); ?>
            <input type="text" name="nama" id="nama" class="form-input" placeholder="Nama Produk" value="<?php echo e($produk->nama); ?>">
            <input type="text" name="varian" id="varian" class="form-input" placeholder="Varian"value="<?php echo e($produk->varian->nama); ?>">
            <input type="text" name="ukuran" id="ukuran" class="form-input" placeholder="Ukuran" value="<?php echo e($produk->ukuran); ?>">
            <input type="number" name="harga" id="harga" class="form-input" placeholder="Harga" value="<?php echo e($produk->harga); ?>">
            <input type="file" name="gambar" id="gambar" class="form-input">
            <textarea name="deskripsi" id="deskrips" cols="30" rows="10" class="form-input"
                      placeholder="Deskripsi"><?php echo e($produk->deskripsi); ?></textarea>
            <div>
                <a href="/">Batal</a>
                <button type="submit">Simpan</button>
            </div>
        </form>
    </main>
    <script src="/js/addVarian.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minerva/PhpstormProjects/ppl_griees/resources/views/pages/produk/edit.blade.php ENDPATH**/ ?>