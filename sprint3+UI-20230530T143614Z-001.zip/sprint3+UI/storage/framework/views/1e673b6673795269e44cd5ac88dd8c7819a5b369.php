<?php $__env->startSection("content"); ?>
    <main class="flex-grow h-screen flex items-center justify-center">
        <form method="POST" class="flex flex-col gap-2" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if($errors->any()): ?>
                <?php echo e(implode('', $errors->all('<div>:message</div>'))); ?>

            <?php endif; ?>
            <label for="paket">Paket</label><select name="paket" id="paket" class="form-input p-1">
                <option value selected disabled>Paket</option>
                <option value="1">Paket 1</option>
            </select>
            <label for="metode">Metode</label><select name="metode" id="metode" class="form-input p-1">
                <option value selected disabled>Metode Pembayaran</option>
                <option value="1">Metode 1</option>
            </select>
            <label for="bukti">Bukti Pembayaran</label>
            <input type="file" name="bukti" id="bukti" class="form-input p-1">
            <button type="submit" class="bg-primary text-white py-2 rounded-full">Daftar</button>
        </form>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.blank", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dobberman/Code/PHP/ppl_alfan/sprint2/resources/views/pages/auth/confirm.blade.php ENDPATH**/ ?>