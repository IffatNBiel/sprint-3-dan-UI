<div id="detailTransaksi-<?php echo e($no+1); ?>" tabindex="-1"
     class="fixed top-0 left-0 right-0 z-50 hidden p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
    <div class="relative w-full max-w-md max-h-full">
        <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
            <div class="p-6 text-center bg-slate-500 rounded-lg">
                <div class="bg-white flex flex-col items-start p-8 gap-3">
                    <p class="font-bold"><?php echo e($transaksi->tanggal); ?></p>
                    <p><?php echo e($transaksi->user->nama? $transaksi->user->nama : "Pegawai"); ?></p>
                    <p><?php echo e($transaksi->user->email); ?></p>
                    <table class="w-full">
                        <tr>
                            <th class="border">Keterangan</th>
                            <th class="border">Harga</th>
                            <th class="border">Jumlah</th>
                            <th class="border">Total</th>
                        </tr>
                        <?php $__currentLoopData = $transaksi->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="border"><?php echo e($detail->produk->nama); ?></td>
                                <td class="border"><?php echo e($detail->produk->harga); ?></td>
                                <td class="border"><?php echo e($detail->jumlah); ?></td>
                                <td class="border"><?php echo e($detail->jumlah * $detail->produk->harga); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <div class="flex flex-col w-full items-end">
                        <p>Total: Rp.<?php echo e($transaksi->total); ?></p>
                        <p>Pajak: Rp.<?php echo e((int)($transaksi->total * 0.1)); ?></p>
                        <p>Total Akhir: Rp.<?php echo e((int)($transaksi->total * 1.1)); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/minerva/PhpstormProjects/ppl_griees/resources/views/pages/transaksi/detail.blade.php ENDPATH**/ ?>