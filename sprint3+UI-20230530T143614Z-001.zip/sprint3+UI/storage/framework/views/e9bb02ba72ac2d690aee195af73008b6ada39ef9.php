<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Griees</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.5/flowbite.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="/css/style.css">
    <script src="https://code.jquery.com/jquery-3.6.4.slim.min.js"
            integrity="sha256-a2yjHM4jnF9f54xUQakjZGaqYs/V1CYvWpoqZzC2/Bw=" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
          rel="stylesheet">
</head>
<body class="flex w-screen">
<nav class="flex flex-col w-1/4 gap-2 p-4">
    <p class="bg-slate-200 p-2 text-center self-stretch mb-4">Logo Griees</p>
    <a href="/"><span class="me-2 text-center bg-black text-white w-5 h-5 px-2 py-1 rounded-full">#</span>Dashboard</a>
    <a href="/transaksi/tambah"><span
            class="me-2 text-center bg-black text-white w-5 h-5 px-2 py-1 rounded-full">#</span>Kasir</a>
    <a href="/produk"><span
            class="me-2 text-center bg-black text-white w-5 h-5 px-2 py-1 rounded-full">#</span>Produk</a>
    <a href="/stok"><span class="me-2 text-center bg-black text-white w-5 h-5 px-2 py-1 rounded-full">#</span>Stok
        Produk</a>
    <a href="/transaksi"><span class="me-2 text-center bg-black text-white w-5 h-5 px-2 py-1 rounded-full">#</span>Riwayat
        Transaksi</a>
    <button id="dropdownDefaultButton" data-dropdown-toggle="dropdown" class="text-start"><span
            class="me-2 text-center bg-black text-white w-5 h-5 px-2 py-1 rounded-full">#</span>Keuangan
    </button>
    <div id="dropdown" class="z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700">
        <ul class="py-2 text-sm text-gray-700" aria-labelledby="dropdownDefaultButton">
            <li>
                <a href="/keuangan/laporan" class="block px-4 py-2">Laporan Keuangan</a>
            </li>
            <li>
                <a href="/keuangan/masuk" class="block px-4 py-2">Arus Kas Masuk</a>
            </li>
            <li>
                <a href="/keuangan/keluar" class="block px-4 py-2">Arus Kas Keluar</a>
            </li>
        </ul>
    </div>
    <?php if(auth()->user() ? auth()->user()->jabatan->jabatan_name === "pemilik" : false): ?>
        <a href="/register"><span class="me-2 text-center bg-black text-white w-5 h-5 px-2 py-1 rounded-full">#</span>Register</a>
    <?php endif; ?>
    <a href="/logout"><span class="me-2 text-center bg-black text-white w-5 h-5 px-2 py-1 rounded-full">#</span>Logout</a>
</nav>
<?php echo $__env->yieldContent("content"); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.5/flowbite.min.js"></script>
</body>
</html>
<?php /**PATH /home/minerva/PhpstormProjects/ppl_griees/resources/views/layouts/auth.blade.php ENDPATH**/ ?>
