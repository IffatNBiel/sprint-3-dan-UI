<?php $__env->startSection("content"); ?>
    <main class="flex-grow px-4 bg-slate-100">
        <div class="bg-primary h-[10%] mb-4"></div>
        <div class="p-4 bg-white h-[calc(100vh-10%-1rem)] overflow-y-scroll">
            <h1 class="text-center font-bold text-2xl mb-3">Riwayat Transaksi</h1>
            <table class="w-full">
                <thead>
                <tr class="bg-primary text-white border-2 border-gray-100">
                    <th class="border-2 border-gray-200 px-8 py-2">No.</th>
                    <th class="border-2 border-gray-200 px-8 py-2">Tanggal</th>
                    <th class="border-2 border-gray-200 px-8 py-2">Jenis Transaksi</th>
                    <th class="border-2 border-gray-200 px-8 py-2">Pembayaran</th>
                    <th class="border-2 border-gray-200 px-8 py-2">Nama Pegawai</th>
                    <th class="border-2 border-gray-200 px-8 py-2">Invoice</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $transaksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center border-2 border-gray-100"><?php echo e($no+1); ?></td>
                        <td class="text-center border-2 border-gray-100"><?php echo e($transaksi->day->tanggal); ?></td>
                        <td class="text-center border-2 border-gray-100"><?php echo e($transaksi->kategori_transaksi); ?></td>
                        <td class="text-center border-2 border-gray-100"><?php echo e($transaksi->total); ?></td>
                        <td class="text-center border-2 border-gray-100"><?php echo e($transaksi->user->name); ?></td>
                        <td class="text-center border-2 border-gray-100">
                            <?php echo $__env->make("pages.transaksi.detail", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <button type="button" data-modal-target="detailTransaksi-<?php echo e($no+1); ?>"
                                    data-modal-toggle="detailTransaksi-<?php echo e($no+1); ?>"
                                    class="material-icons">file_open
                            </button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.auth", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dobberman/Code/PHP/ppl_alfan/sprint2/resources/views/pages/transaksi/index.blade.php ENDPATH**/ ?>