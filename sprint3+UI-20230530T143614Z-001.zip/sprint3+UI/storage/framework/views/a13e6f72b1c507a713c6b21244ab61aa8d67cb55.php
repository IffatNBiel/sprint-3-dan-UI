<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Griees</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.5/flowbite.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="/css/style.css">
    <script src="https://code.jquery.com/jquery-3.6.4.slim.min.js"
            integrity="sha256-a2yjHM4jnF9f54xUQakjZGaqYs/V1CYvWpoqZzC2/Bw=" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
          rel="stylesheet">
</head>
<body class="h-screen overflow-y-hidden w-screen">
<nav class="flex justify-between items-center text-white font-medium bg-primary h-[10%] w-full px-8 py-2">
    <div class="flex items-center gap-4">
        <img src="/images/logo.png" class="h-10" alt="">
        <a href="/#home">Beranda</a>
        <a href="/#packet">Paket Berlangganan</a>
        <a href="/#about">Tentang Griees</a>
    </div>
    <div class="flex items-center gap-4">
        <?php if(auth()->guard()->check()): ?>
            <a href="/dashboard">Dashboard</a>
            <a href="/logout">Logout</a>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
            <a href="/login">Login</a>
            <a href="/register">Register</a>
        <?php endif; ?>
    </div>
</nav>
<?php echo $__env->yieldContent("content"); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.5/flowbite.min.js"></script>
</body>
</html>
<?php /**PATH /home/dobberman/Code/PHP/ppl_alfan/sprint2/resources/views/layouts/blank.blade.php ENDPATH**/ ?>