<?php $__env->startSection("content"); ?>
    <div class="p-4 flex flex-col bg-white items-center h-[calc(100vh-10%-1rem)] overflow-y-scroll">
        <div class="flex justify-between w-full items-center mb-4">
            <h1 class="flex-grow text-center font-bold text-2xl">Arus Kas Keluar</h1>
            <a href="/keuangan/keluar/tambah"
               class="mt-4 w-1/3 text-center bg-primary py-2 rounded-xl text-white">Tambah
                Data</a>
        </div>
        <table class="w-full">
            <thead>
            <tr class="bg-primary text-white">
                <th class="border-2 border-gray-200 px-8 py-2">No.</th>
                <th class="border-2 border-gray-200 px-8 py-2">Tanggal</th>
                <th class="border-2 border-gray-200 px-8 py-2 w-1/3">Jenis Pengeluaran</th>
                <th class="border-2 border-gray-200 px-8 py-2 w-1/3">Jumlah Pengeluaran</th>
                <th class="border-2 border-gray-200 px-8 py-2">Keterangan</th>
                <th class="border-2 border-gray-200 px-8 py-2">Bukti Pengeluaran</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $keluars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$keluar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center border-gray-200 border-2"><?php echo e($i+1); ?></td>
                    <td class="text-center border-gray-200 border-2"><?php echo e($keluar->created_at); ?></td>
                    <td class="text-center border-gray-200 border-2"><?php echo e($keluar->jenis_pengeluaran); ?></td>
                    <td class="text-center border-gray-200 border-2"><?php echo e($keluar->jumlah_pengeluaran); ?></td>
                    <td class="text-center border-gray-200 border-2"><?php echo e($keluar->keterangan); ?></td>
                    <td class="text-center border-gray-200 border-2"><a href="/<?php echo e($keluar->bukti); ?>">Bukti</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.auth", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dobberman/Code/PHP/ppl_alfan/sprint2/resources/views/pages/keuangan/kaskeluar/index.blade.php ENDPATH**/ ?>