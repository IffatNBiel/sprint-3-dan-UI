<?php $__env->startSection("content"); ?>
    <div class="bg-white p-4 flex flex-col gap-8">
        <div class="flex flex-col items-center gap-4">
            <h1 class="font-bold text-2xl">VISUALISASI DATA PENJUALAN</h1>
            <form>
                <select onchange="submit()" class="px-4 py-1" name="tahun" id="tahun">
                    <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($year["tahun"]); ?>" <?php echo e($year["tahun"] == $tahun ?"selected":""); ?>>
                            Tahun <?php echo e($year["tahun"]); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </form>
        </div>
        <div class="flex justify-center gap-4">
            <div class="flex justify-between items-end px-4 py-2 bg-slate-400 rounded-xl">
                <span class="w-1/4">Jumlah Transaksi</span>
                <span class="bg-black w-1 h-full"></span>
                <span class="text-5xl font-bold"><?php echo e($data["n_transaksi"]); ?></span>
                <span class="text-sm">Transaksi</span>
            </div>
            <div class="flex justify-between items-end px-4 py-2 bg-slate-400 rounded-xl">
                <span class="w-1/2">Jumlah Produk Terjual</span>
                <span class="bg-black w-1 h-full"></span>
                <span class="text-5xl font-bold"><?php echo e($data["n_produk"]); ?></span>
                <span class="text-sm">Produk</span>
            </div>
        </div>
        <div class="flex gap-4">
            <div class="w-1/2 flex flex-col items-center">
                <canvas id="jumlah" class="w-1/2"></canvas>
                <h1>Grafik Jumlah Transaksi</h1>
            </div>
            <div class="w-1/2 flex flex-col items-center">
                <canvas id="jumlahproduk" class="w-1/4"></canvas>
                <h1>Grafik Jumlah Produk Terjual</h1>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const ctxjumlah = document.getElementById('jumlah');
        new Chart(ctxjumlah, {
            type: 'bar',
            data: {
                labels: [
                    <?php $__currentLoopData = $data["graph"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        "<?php echo e($d["tanggal"]); ?>",
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],
                datasets: [{
                    label: 'Jumlah Transaksi',
                    data: [
                        <?php $__currentLoopData = $data["graph"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            "<?php echo e($d["jumlah_transaksi"]); ?>",
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
        const ctxjumlahproduk = document.getElementById('jumlahproduk');
        new Chart(ctxjumlahproduk, {
            type: 'bar',
            data: {
                labels: [
                    <?php $__currentLoopData = $data["graph"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        "<?php echo e($d["tanggal"]); ?>",
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],
                datasets: [{
                    label: 'Produk Terjual',
                    data: [
                        <?php $__currentLoopData = $data["graph"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            "<?php echo e($d["jumlah_produk"]); ?>",
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.auth", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dobberman/Code/PHP/ppl_alfan/sprint2/resources/views/pages/keuangan/grafik.blade.php ENDPATH**/ ?>