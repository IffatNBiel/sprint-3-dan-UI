<?php $__env->startSection("content"); ?>
    <main class="flex-grow">
        <form method="post" enctype="multipart/form-data" class="p-4 flex flex-col items-center">
            <?php echo csrf_field(); ?>
            <h1>BORANG ISIAN KAS KELUAR</h1>
            <div class="flex">
                <div class="flex flex-col">
                    <input type="date" name="created_at" id="created_at">
                    <select name="jenis_pengeluaran" id="jenis_pengeluaran">
                        <option value="gaji">Gaji</option>
                        <option value="belanja bahan">Belanja Bahan</option>
                        <option value="lainnya">Lainnya</option>
                    </select>
                    <input type="number" name="jumlah_pengeluaran" id="jumlah_pengeluaran">
                    <textarea name="keterangan" id="keterangan" cols="30" rows="10"></textarea>
                </div>
                <div>
                    <input type="file" name="filebukti" id="filebukti">
                </div>
            </div>
            <button type="submit">Simpan</button>
        </form>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minerva/PhpstormProjects/ppl_griees/resources/views/pages/keuangan/kaskeluar/tambah.blade.php ENDPATH**/ ?>