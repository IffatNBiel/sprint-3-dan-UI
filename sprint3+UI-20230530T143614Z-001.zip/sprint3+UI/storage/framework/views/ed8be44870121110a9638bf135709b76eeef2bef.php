<?php $__env->startSection("content"); ?>
    <?php echo $__env->make("pages.stok.tambah", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("pages.stok.edit", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("pages.stok.detail", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="flex-grow">
        <button data-modal-target="tambahStok" data-modal-toggle="tambahStok" class="px-4 py-2 bg-slate-500 text-white my-2">Tambah Stok Produk</button>
        <table class="w-full">
            <thead>
            <tr class="bg-gray-100">
                <th class="px-8 py-2">No.</th>
                <th class="px-8 py-2">Id Produk</th>
                <th class="px-8 py-2">Nama Produk</th>
                <th class="px-8 py-2">Stok Produk</th>
                <th class="px-8 py-2">Status</th>
                <th class="px-8 py-2">Deskripsi</th>
                <th class="px-8 py-2">Edit</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="<?php if($produk->stok===0): ?> bg-gray-300 <?php endif; ?>">
                    <td data-modal-target="detailStok" data-modal-toggle="detailStok" onclick="detailStok('<?php echo e($produk->nama); ?>','<?php echo e($produk->stok); ?>','<?php echo e($produk->deskripsi); ?>')" class="border border-2 border-gray-100 p-2 text-center"><?php echo e($i+1); ?></td>
                    <td data-modal-target="detailStok" data-modal-toggle="detailStok" onclick="detailStok('<?php echo e($produk->nama); ?>','<?php echo e($produk->stok); ?>','<?php echo e($produk->deskripsi); ?>')" class="border border-2 border-gray-100 p-2"><?php echo e($produk->id); ?></td>
                    <td data-modal-target="detailStok" data-modal-toggle="detailStok" onclick="detailStok('<?php echo e($produk->nama); ?>','<?php echo e($produk->stok); ?>','<?php echo e($produk->deskripsi); ?>')" class="border border-2 border-gray-100 p-2"><?php echo e($produk->nama); ?></td>
                    <td data-modal-target="detailStok" data-modal-toggle="detailStok" onclick="detailStok('<?php echo e($produk->nama); ?>','<?php echo e($produk->stok); ?>','<?php echo e($produk->deskripsi); ?>')" class="border border-2 border-gray-100 p-2 text-center"><?php echo e($produk->stok); ?></td>
                    <td data-modal-target="detailStok" data-modal-toggle="detailStok" onclick="detailStok('<?php echo e($produk->nama); ?>','<?php echo e($produk->stok); ?>','<?php echo e($produk->deskripsi); ?>')" class="border border-2 border-gray-100 p-2 text-center"><?php echo e($produk->stok>0?"Tersedia":"Habis"); ?></td>
                    <td data-modal-target="detailStok" data-modal-toggle="detailStok" onclick="detailStok('<?php echo e($produk->nama); ?>','<?php echo e($produk->stok); ?>','<?php echo e($produk->deskripsi); ?>')" class="border border-2 border-gray-100 p-2"><?php echo e(Str::limit($produk->deskripsi, $limit = 20, $end = '...')); ?></td>
                    <td class="border border-2 border-gray-100 p-2 text-center">
                        <button onclick="editStok('<?php echo e($produk->id); ?>','<?php echo e($produk->nama); ?>','<?php echo e($produk->stok); ?>')"
                                data-modal-target="editStok" data-modal-toggle="editStok" class="material-icons">
                            edit
                        </button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minerva/PhpstormProjects/ppl_griees/resources/views/pages/stok/index.blade.php ENDPATH**/ ?>