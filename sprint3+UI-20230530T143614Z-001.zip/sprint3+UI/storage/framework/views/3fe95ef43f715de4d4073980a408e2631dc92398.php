<?php $__env->startSection("content"); ?>
    <main>
        <?php if(auth()->guard()->guest()): ?>
            <a href="/login">Login</a>
        <?php endif; ?>
        <?php if(auth()->guard()->check()): ?>
            <a href="/produk/tambah">tambah produk</a>
        <?php endif; ?>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minerva/PhpstormProjects/ppl_griees/resources/views/index.blade.php ENDPATH**/ ?>
