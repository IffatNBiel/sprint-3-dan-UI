<?php $__env->startSection("content"); ?>
    <main>
        <form action="/varian/tambah" method="POST" class="flex flex-col">
            <?php echo csrf_field(); ?>
            <input type="text" name="nama" id="nama" class="form-input" placeholder="Nama Varian">
            <textarea name="deskripsi" id="deskripsi" cols="30" rows="10" placeholder="Deskripsi" class="form-input"></textarea>
            <div>
                <a href="/">Batal</a>
                <button type="submit">Simpan</button>
            </div>
        </form>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minerva/PhpstormProjects/ppl_griees/resources/views/pages/produk/tambahvarian.blade.php ENDPATH**/ ?>