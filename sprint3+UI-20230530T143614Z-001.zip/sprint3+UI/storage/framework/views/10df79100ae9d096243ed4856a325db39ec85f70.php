<?php $__env->startSection("content"); ?>
<main class="flex-grow h-screen flex items-center justify-center">
    <form action="/login" method="POST" class="flex flex-col gap-2">
        <?php echo csrf_field(); ?>
        <input type="email" name="email" id="email" placeholder="Email">
        <input type="password" name="password" id="password" placeholder="Password">
        <button type="submit" class="bg-slate-200 py-2 rounded-full">Login</button>
    </form>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minerva/PhpstormProjects/ppl_griees/resources/views/pages/auth/login.blade.php ENDPATH**/ ?>