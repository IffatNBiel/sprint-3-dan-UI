@extends("layouts.auth")
@section("content")
    @if(session("message"))
        <div data-modal-target="popup-modal"></div>
        <div id="popup-modal" tabindex="-1"
             class="fixed flex z-50 p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
            <div class="relative w-full max-w-md max-h-full">
                <div class="relative rounded-lg shadow bg-white">
                    <button type="button"
                            class="absolute top-3 right-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-800 dark:hover:text-white"
                            data-modal-hide="popup-modal">
                        <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                             xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd"
                                  d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                  clip-rule="evenodd"></path>
                        </svg>
                        <span class="sr-only">Close modal</span>
                    </button>
                    <div class="p-6 text-center">
                        <svg aria-hidden="true" class="mx-auto mb-4 text-gray-400 w-14 h-14 dark:text-gray-200"
                             fill="none" stroke="currentColor" viewBox="0 0 24 24"
                             xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                        <h3 class="mb-5 text-lg font-normal text-gray-500 dark:text-gray-400">{{session("message")}}</h3>
                    </div>
                </div>
            </div>
        </div>
    @endif
    <div class="h-[calc(100vh-10%-1rem)] flex gap-4">
        <div class="p-4 bg-white">
            <div class="flex justify-between items-center h-16">
                <form action="/produk" class="flex items-center w-1/3 bg-white rounded-xl border-2 border-primary">
                    <label for="keyword" class="material-icons px-2">search</label>
                    <input type="text" name="keyword" id="keyword" class="bg-white py-1 border-none w-2/3">
                    <button class="px-4 py-1 rounded-e-xl border-s-2 border-primary w-1/4">Cari</button>
                </form>
                <h1 class="font-bold text-2xl flex-grow text-center">Daftar Produk</h1>
                <div class="w-1/3 flex justify-end">
                    <a href="/produk/tambah" class="bg-primary text-white py-2 px-4 rounded-xl">Tambah Produk</a>
                </div>
            </div>
            <div class="flex flex-wrap h-[calc(90%-1rem)] overflow-y-scroll">
                @foreach($produks as $produk)
                    <div class="w-[25%] p-1">
                        <button data-modal-target="dataProduk" data-modal-toggle="dataProduk"
                                onclick="getDataProduk('{{$produk->id}}', '{{$produk->nama}}', '{{$produk->gambar}}', '{{$produk->varian->nama}}', '{{$produk->ukuran}}', '{{$produk->harga}}', '{{$produk->deskripsi}}')"
                                class="px-2 py-3 bg-gray-200 w-full flex flex-col gap-2 items-center">
                            <img src="/{{$produk->gambar}}" class="border h-52 w-full object-cover"
                                 alt="{{$produk->gambar}}">
                            <span class="capitalize font-bold text-xl">{{$produk->nama}}</span>
                            <span>Rp. {{$produk->harga}}</span>
                        </button>
                    </div>
                @endforeach
            </div>
        </div>
        @yield("sidebar")
    </div>
    @include("pages.produk.dataProduk")
    <script src="/js/getDataProduk.js"></script>
@stop
